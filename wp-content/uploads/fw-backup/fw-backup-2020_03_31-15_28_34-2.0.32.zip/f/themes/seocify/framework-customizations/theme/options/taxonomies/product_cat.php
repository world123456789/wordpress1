<?php if ( !defined( 'FW' ) ) {	die( 'Forbidden' ); }

$options = array(
    'xs_product_cat'=>array(
        'type'  => 'new-icon',
        'value' => '',
        'label' =>esc_html__('Product Icon', 'seocify'),
        'desc'  =>esc_html__('Product Icon', 'seocify'),
    ),
);